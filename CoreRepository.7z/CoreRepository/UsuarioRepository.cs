﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreRepository
{
    public class UsuarioRepository
    {
        string dbConn = ConfigurationManager

        public bool CrearUsuario(Usuario entity)
        {
            return true;
        }

        public bool EditarUsuario(Usuario entity)
        {
            return true;
        }

        public Usuario BuscarUsuario(int idUsuario)
        {
            Usuario mock = new Usuario();
            mock.IdUsuario = 1;
            mock.Nombre = "Nombre1";
            mock.Apellido = "Apellido1";
            mock.Correo = "Correo1";
            mock.Telefono = "111111111";
            mock.Contrasena = "asdfg";
            mock.IsActivo = true;
            return mock;
        }

        public List<Usuario> ListarUsuarios()
        {
            Usuario mock1 = new Usuario();
            mock1.IdUsuario = 1;
            mock1.Nombre = "Nombre1";
            mock1.Apellido = "Apellido1";
            mock1.Correo = "Correo1";
            mock1.Telefono = "111111111";
            mock1.Contrasena = "asdfg";
            mock1.IsActivo = true;

            Usuario mock2 = new Usuario();
            mock2.IdUsuario = 2;
            mock2.Nombre = "Nombre2";
            mock2.Apellido = "Apellido2";
            mock2.Correo = "Correo2";
            mock2.Telefono = "222222222";
            mock2.Contrasena = "asdfg";
            mock2.IsActivo = true;

            Usuario mock3 = new Usuario();
            mock3.IdUsuario = 3;
            mock3.Nombre = "Nombre3";
            mock3.Apellido = "Apellido3";
            mock3.Correo = "Correo3";
            mock3.Telefono = "33333333";
            mock3.Contrasena = "asdfg";
            mock3.IsActivo = true;

            List<Usuario> listMocks = new List<Usuario>();
            listMocks.Add(mock1);
            listMocks.Add(mock2);
            listMocks.Add(mock3);
            return listMocks;
        }

        public bool EliminarUsuario(int idUsuario)
        {
            return true;
        }
    }
}
