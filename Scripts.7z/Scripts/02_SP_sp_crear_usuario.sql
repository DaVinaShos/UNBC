use Unbc2024;

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_crear_usuario]
	@Nombre varchar(50),
	@Apellido varchar(50),
	@Correo varchar(100),
	@Telefono varchar(15),
	@Contrasena varchar(50),
	@IsActivo bit
AS
BEGIN
	SET NOCOUNT ON;

    INSERT INTO [dbo].[Usuarios]
           ([Nombre]
           ,[Apellido]
           ,[Correo]
           ,[Telefono]
           ,[Contrasena]
           ,[IsActivo])
     VALUES
           (@Nombre
           ,@Apellido
           ,@Correo
           ,@Telefono
           ,@Contrasena
           ,@IsActivo)
END
GO
