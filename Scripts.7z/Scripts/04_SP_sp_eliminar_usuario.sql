use Unbc2024;

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_eliminar_usuario]
	@IdUsuario int
AS
BEGIN
	SET NOCOUNT ON;

    DELETE FROM [dbo].[Usuarios]
    WHERE IdUsuario = @IdUsuario
END
GO
