use Unbc2024;

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_listar_usuarios]
AS
BEGIN
	SET NOCOUNT ON;

    SELECT [IdUsuario]
      ,[Nombre]
      ,[Apellido]
      ,[Correo]
      ,[Telefono]
      ,[Contrasena]
      ,[IsActivo]
	FROM [dbo].[Usuarios]

END
GO
