use Unbc2024;

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_buscar_usuario]
	@IdUsuario int
AS
BEGIN
	SET NOCOUNT ON;

    SELECT [IdUsuario]
      ,[Nombre]
      ,[Apellido]
      ,[Correo]
      ,[Telefono]
      ,[Contrasena]
      ,[IsActivo]
	FROM [dbo].[Usuarios]
	WHERE IdUsuario = @IdUsuario

END
GO
