USE Unbc2024

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_login_usuario]
	@Usuario varchar(50),
	@Contrasena varchar(50)
AS
BEGIN

	SET NOCOUNT ON;

    SELECT [IdUsuario]
      ,[Nombre]
      ,[Apellido]
      ,[Correo]
      ,[Telefono]
      ,[Contrasena]
      ,[IsActivo]
	FROM [dbo].[Usuarios]
	WHERE Nombre = @Usuario
	AND Contrasena = @Contrasena

END
GO
