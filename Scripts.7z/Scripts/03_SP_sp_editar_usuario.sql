use Unbc2024;

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_editar_usuario]
	@IdUsuario int,
	@Nombre varchar(50),
	@Apellido varchar(50),
	@Correo varchar(100),
	@Telefono varchar(15),
	@Contrasena varchar(50),
	@IsActivo bit
AS
BEGIN
	SET NOCOUNT ON;

   UPDATE [dbo].[Usuarios]
   SET [Nombre] = @Nombre
      ,[Apellido] = @Apellido
      ,[Correo] = @Correo
      ,[Telefono] = @Telefono
      ,[Contrasena] = @Contrasena
      ,[IsActivo] = @IsActivo
	WHERE IdUsuario = @IdUsuario

END
GO
