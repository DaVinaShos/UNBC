use Unbc2024;

create table Usuarios(
	IdUsuario int primary key identity(1,1) not null,
	Nombre varchar(50) not null,
	Apellido varchar(50) not null,
	Correo varchar(100) not null,
	Telefono varchar(15) not null,
	Contrasena varchar(50) not null,
	IsActivo bit not null default 0
)